import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import {FilterableProductTable,PRODUCTS} from './SearchProduct/FilterableProductTable'
import CartPanel from './ShoppingCart/CartPanel';

function App() {
  return (
    <div className="App">
      
{/* <FilterableProductTable products={PRODUCTS} /> */}
<CartPanel></CartPanel>
    </div>
  );
}

export default App;
