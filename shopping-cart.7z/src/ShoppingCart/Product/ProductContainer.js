import React from 'react'
import ProductCard from './ProductCard'

function ProductContainer(props) {
var categoryProducts = props.products.categoryProducts;
  return (
    <>
      {categoryProducts.map((b) => {
        return (
          <ProductCard data={b}></ProductCard>
        )
      })}
    </>
  )
}

export default ProductContainer