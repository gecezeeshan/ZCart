import React from 'react'
import { Button } from 'react-bootstrap';

import { Card } from 'react-bootstrap';

function ProductCard(props) {
  return (
    <div style={{marginBottom: '10px'}}>


      <Card style={{ width: '18rem' }}>
        {/* <Card.Img variant="top" src="holder.js/100px180" /> */}
        <Card.Body>
          <Card.Title>{props.data.name}</Card.Title>
          <Card.Text>
            <p className='ellipseText'>    {props.data.description}</p>
            <div> <p className={'strike'}>${parseFloat(props.data.price) + 10} </p>
              ${props.data.price}</div>
          </Card.Text>
          <Button variant="outline-secondary">Add to cart</Button>
        </Card.Body>
      </Card>
    </div>
  )
}

export default ProductCard