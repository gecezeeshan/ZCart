import React from 'react'

import { Accordion } from 'react-bootstrap';
import CartProductCategory from '../Category/CartProductCategory'
import ProductContainer from './ProductContainer';
function CartProductPanel(props) {
  var data = props.data;
  var index = 0;
  return (
    <>     
      {data.map((e) => {
        return (
          <>
          <table><tr><td></td><td>
 <ProductContainer products={e}></ProductContainer></td></tr></table>
            {/* <Accordion defaultActiveKey="0">
              <Accordion.Item eventKey={index}>
                <Accordion.Header><CartProductCategory catData={e}></CartProductCategory></Accordion.Header>
                <Accordion.Body>
                  <ProductContainer products={e}></ProductContainer>
                </Accordion.Body>
              </Accordion.Item>
            </Accordion> */}

            
          </>

        )
        index++;
      })
      }


    </>
  )
}

export default CartProductPanel