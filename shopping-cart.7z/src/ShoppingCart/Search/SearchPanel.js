import React from 'react'
import InputGroup from 'react-bootstrap/InputGroup';
import Form from 'react-bootstrap/Form';
import Container from 'react-bootstrap/Container'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'


function SearchPanel(props) {

    const handleFilterTextChange = (e) => {
        props.onFilterTextChange(e.target.value);
    }

    const handleInStockChange = (e) => {
        props.onInStockChange(e.target.checked);
    }

    return (
        <form>
            <table width="80%"><tr><td width="80%">

      

                
            </td><td style={{ paddingLeft: '10px' }}>
                   
                </td></tr></table>

        
<Container fluid>
<Row>
    <Col><input type="text" placeholder="Search Product" value={props.filterText}
                        onChange={handleFilterTextChange} width="500px"></input></Col>
    <Col> <span style={{ width: '100px' }}>
                        <Form.Group className="mb-3" controlId="formBasicCheckbox">
                            <Form.Check type="checkbox" label="In stock only" checked={props.inStockOnly}
                                onChange={handleInStockChange} />
                        </Form.Group>
                    </span></Col>
  </Row>
</Container>

        </form>


    )
}

export default SearchPanel