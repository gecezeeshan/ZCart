import React, { useState, useEffect } from 'react'

import ShoppingCartData from './ShoppingCartData';
import CartProductPanel from './Product/CartProductPanel';
import SearchPanel from './Search/SearchPanel';

export default function CartPanel() {
    //var ShoppingCartData.CartRepository;
    var cartData = [];
    const [filterText, setFilterText] = useState('');
    const [inStockOnly, setInStockOnly] = useState(false);

    const handleFilterTextChange = (filterText) => {
        setFilterText(filterText);
    }

    const handleInStockChange = (inStockOnly) => {
        setInStockOnly(inStockOnly);
    }
  
    

    const modifyCartData = () => {
       
        ShoppingCartData.CartRepository.CartCategories.map((a) => {

            var products = ShoppingCartData.CartRepository.CartProducts.filter((b) => {
                return b.CategoryId == a.CategoryId && (b.name.toLocaleLowerCase().indexOf(filterText.toLocaleLowerCase()) >= 0 || filterText == "")
            });          
            if (products != null) {
                var obj = {
                    category: a, categoryProducts: products
                };
                cartData.push(obj);
            }
            
        });
        cartData = cartData.filter((a)=>{          
           return (a.categoryProducts.length > 0) 
        });
       
    }

    modifyCartData();

    return (
        <>
            <div>CartPanel</div>
            
            <SearchPanel onFilterTextChange={handleFilterTextChange}
                onInStockChange={handleInStockChange}></SearchPanel>

            <CartProductPanel data={cartData} ></CartProductPanel>
        </>
    )
}
