import React from 'react';

function CartProductCategory(props) {
    var currentCategory = props.catData;
  return (
    <>    
    <div ><b>{currentCategory.category.categoryName} </b></div>
    </>
  )
}

export default CartProductCategory